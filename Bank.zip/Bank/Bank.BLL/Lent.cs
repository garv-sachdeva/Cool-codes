﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank.DAL;
using Bank.DTO;

namespace Bank.BLL
{
   public class Lent
    {
       public DTO.Lent MoneyInfo;
       List<DTO.Lent> list;

       public static DTO.Lent GetUser(int Id)
       {
           if (Id > 0)
           {
             return  MoneyLent.GetUser(Id);
           }
           else
           {
               return new DTO.Lent();
           }
       }

       public static void AddPerson(DTO.Lent lent)
       {
           MoneyLent.InsertUser(lent);
       }

       public static void UpdatePerson(DTO.Lent lent)
       {
           MoneyLent.UpdateUser(lent);
       }
       public static void DeleteUser(int Id)
       {
           MoneyLent.DeleteUser(Id);
       }

       public static List<DTO.Lent> GetAllUser()
       {
         return  MoneyLent.GetAllUser();
       }
    }
}
