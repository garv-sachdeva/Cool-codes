﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bank.DAL;
using Bank.DTO;


namespace Bank.BLL
{
    public class Person
    {
        public DTO.Person personInfo;
        List<DTO.Person> listOfPersons;

        public static DTO.Person GetPerson(int PersonID)
        {
            if (PersonID > 0)
            {
                return PersonManager.GetPerson(PersonID);
            }
            else
            {
                return new DTO.Person();
            }
        }

        public static void AddPerson(DTO.Person person)
        {
            PersonManager.InsertPerson(person);
        }

        public static void DeletePerson(int PersonID)
        {
            PersonManager.DeletePerson(PersonID);
        }

        public static void UpdatePerson(DTO.Person person)
        {
            PersonManager.UpdatePerson(person);
        }
        public static List<DTO.Person> GetAllPersons()
        {
            return PersonManager.GetAllPerson();
        }


    }
}