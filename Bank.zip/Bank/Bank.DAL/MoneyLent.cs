﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Bank.DTO;

namespace Bank.DAL
{
    public static class MoneyLent
    {


        /// <summary>
        /// Gets the user.
        /// </summary>
        /// <param name="Id">The identifier.</param>
        /// <returns>Lent.</returns>
        /// <exception cref="System.ApplicationException"></exception>
        public static Lent GetUser(int Id)
        {
            Lent Moneyinfo = new Lent();
            using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetCustomer";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@id", Moneyinfo.Id);
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            Moneyinfo = ReadUser(dr);
                        }
                        else
                        {
                            throw new ApplicationException(string.Format("customer[0] not found", Moneyinfo.Id));
                        }
                    }
                }

            }
            return Moneyinfo;

        }

        /// <summary>
        /// Reads the user.
        /// </summary>
        /// <param name="dr">The dr.</param>
        /// <returns>Lent.</returns>
        public static Lent ReadUser(SqlDataReader dr)
        {
            Lent Moneyinfo = new Lent();
            Moneyinfo.Id = (int)dr["Customer Id"];
            Moneyinfo.Name = dr["Customer Name"] as string;
            Moneyinfo.Amount = (double)dr["Amount Lent"];
            Moneyinfo.PersonId = (int)dr["Person Id"];
            return Moneyinfo;
        }

        public static Lent InsertUser(Lent Moneyinfo)
        {
            using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "AddCustomer";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@name", Moneyinfo.Name);
                    cm.Parameters.AddWithValue("@amount", Moneyinfo.Amount);
                    cm.Parameters.AddWithValue("@personId", Moneyinfo.PersonId);
                    Moneyinfo.Id = Convert.ToInt32(cm.ExecuteScalar());
                }
            }
            return Moneyinfo;
        }

        public static List<Lent> GetAllUser()
        {
            List<Lent> list = new List<Lent>();
            using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetAllCustomer";
                    cm.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            list.Add(ReadUser(dr));
                        }
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="Moneyinfo">The moneyinfo.</param>
        public static void UpdateUser(Lent Moneyinfo)
        {
            using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "UpdateCustomer";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@id", Moneyinfo.Id);
                    cm.Parameters.AddWithValue("@name", Moneyinfo.Name);
                    cm.Parameters.AddWithValue("@amount", Moneyinfo.Amount);
                    cm.Parameters.AddWithValue("@personId", Moneyinfo.PersonId);
                    cm.ExecuteNonQuery();
                }
            }

        }

        /// <summary>
        /// Deletes the user.
        /// </summary>
        /// <param name="Id">The identifier.</param>
        public static void DeleteUser(int Id)
        {
            using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "DeleteCustomer";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@id", Id);
                    cm.ExecuteNonQuery();
                }
            }
        }
        
    }
}
