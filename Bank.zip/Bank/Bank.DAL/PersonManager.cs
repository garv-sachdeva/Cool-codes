﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Bank.DTO;

namespace Bank.DAL
{
   public static class PersonManager
    {
       

       public static Person GetPerson(int personId)
       {
           Person personInfo = new Person();
           personInfo.PersonId = personId;
           using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
           {
               cn.Open();
               using (SqlCommand cm = cn.CreateCommand())
               {
                   cm.CommandText = "GetBalance";
                   cm.CommandType = CommandType.StoredProcedure;
                   cm.Parameters.AddWithValue("@personId", personInfo.PersonId);
                   using (SqlDataReader dr = cm.ExecuteReader())
                   {
                       if (dr.Read())
                       {
                           personInfo = ReadPerson(dr);
                       }
                       else
                       {
                           throw new ApplicationException(string.Format("Person[0] not found", personInfo.PersonId));
                       }
                   }
               }

           }
           return personInfo;
       }

       public static List<Person> GetAllPerson()
       {
           List<Person> person = new List<Person>();
           using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
           {
               cn.Open();
               using (SqlCommand cm = cn.CreateCommand())
               {
                   cm.CommandText = "GetAllPerson";
                   cm.CommandType = CommandType.StoredProcedure;
                   using (SqlDataReader dr = cm.ExecuteReader())
                   {
                     while (dr.Read())
                       {
                           person.Add(ReadPerson(dr));
                       }
                   }
               }
           }
           return person;
       }





       public static Person ReadPerson(SqlDataReader dr)
       {
           Person personInfo = new Person();
           personInfo.PersonId = (int)dr["Person Id"];
           personInfo.Name = dr["Name"] as string;
           personInfo.Balance = (double) dr["Balance"];
           return personInfo;
       }

       public static Person InsertPerson(Person personInfo)
       {
           using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
           {
               cn.Open();
               using (SqlCommand cm = cn.CreateCommand())
               {
                   cm.CommandText = "AddPerson";
                   cm.CommandType = CommandType.StoredProcedure;
                   cm.Parameters.AddWithValue("@name", personInfo.Name);
                   cm.Parameters.AddWithValue("@balance", personInfo.Balance);

                   personInfo.PersonId = Convert.ToInt32(cm.ExecuteScalar());
                   
               }
           }
           return personInfo;
       }

       public static void UpdatePerson(Person personInfo)
       {
           using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
           {
               cn.Open();
               using (SqlCommand cm = cn.CreateCommand())
               {
                   cm.CommandText = "UpdatePerson";
                   cm.CommandType = CommandType.StoredProcedure;
                   cm.Parameters.AddWithValue("@personId", personInfo.PersonId);
                   cm.Parameters.AddWithValue("@name", personInfo.Name);
                   cm.Parameters.AddWithValue("@balance", personInfo.Balance);
                   cm.ExecuteNonQuery();
               }
           }
           
       }

       public static void DeletePerson(int PersonId)
       {
           using (SqlConnection cn = new SqlConnection(Database.ConnectionString))
           {
               cn.Open();
               using (SqlCommand cm = cn.CreateCommand())
               {
                   cm.CommandText = "DeletePerson";
                   cm.CommandType = CommandType.StoredProcedure;
                   cm.Parameters.AddWithValue("@personId", PersonId);
                   cm.ExecuteNonQuery();

               }
           }
       }
    }
}
