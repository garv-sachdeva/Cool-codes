﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank.DTO
{

        public struct Person
        {
            public string Name{get;set;}
            public double Balance{get;set;}
            public int PersonId{get;set;}
        }

        public struct Lent
        {
            public int Id{get;set;}
            public string Name { get;set;}
            public double Amount{get;set;}
            public int PersonId {get;set;}
        }
    }

