﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GovtPortal.Model;
using GovtPortal.DAL;

namespace GovtPortal.BLL
{
    public class PortalManagerBLL
    {
        /// <summary>
        /// Adds the user.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>System.Int32.</returns>
        public static int AddUser(UserInfo user)
        {
            user.UserId = 0;
            int userID = PortalManagerDAL.AddUser(user);
            return userID;
        }

        /// <summary>
        /// Gets all user.
        /// </summary>
        /// <returns>List&lt;UserInfo&gt;.</returns>
        public static List<UserInfo> GetAllUser()
        {
            List<UserInfo> listOfUser = new List<UserInfo>();
            listOfUser = PortalManagerDAL.GetAllUser();
            return listOfUser;
        }

        /// <summary>
        /// Gets the user details.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>UserInfo.</returns>
        public static UserInfo GetUserDetails(int userId)
        {
            UserInfo user = new UserInfo();
            user = PortalManagerDAL.GetUserDetails(userId);
            user.UserId = userId;
            return user;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="editUser">The edit user.</param>
        public static void UpdateUser(UserInfo editUser)
        {
            PortalManagerDAL.UpdateUser(editUser);
        }

        /// <summary>
        /// Deletes the employee.
        /// </summary>
        /// <param name="UserId">The user identifier.</param>
        public static void DeleteEmployee(int UserId)
        {
            PortalManagerDAL.DeleteUser(UserId);
        }
    }
}
