﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GovtPortal.BLL;
using GovtPortal.Model;

namespace GovtPortal.Cons
{
    class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            List<UserInfo> listOfUsers = new List<UserInfo>();
            Console.WriteLine("List Of All Users \n");
            listOfUsers = PortalManagerBLL.GetAllUser();

            foreach (var user in listOfUsers)
            {
                Console.WriteLine("{0},{1},{2},{3},{4},{5}",user.UserId, user.Name, user.City, user.Phone, user.DepartmentName, user.Ideas);
            }

            Console.WriteLine("Do you want to add User ? (y/n)");
            char choice = Convert.ToChar(Console.ReadLine());

            if (choice == 'y' || choice == 'Y')
            {
                UserInfo user = new UserInfo();
                Console.WriteLine("Enter Name : ");
                user.Name = Console.ReadLine();
                Console.WriteLine("Enter City : ");
                user.City = Console.ReadLine();
                Console.WriteLine("Enter Phone : ");
                user.Phone = Console.ReadLine();
                Console.WriteLine("Enter DepartmentName : ");
                user.DepartmentName = Console.ReadLine();
                Console.WriteLine("Do you Have any Ideas : ");
                user.Ideas = Console.ReadLine();

                user.UserId = PortalManagerBLL.AddUser(user);

                Console.WriteLine("Your UserID : {0}", user.UserId);
            }
            else
            {
                Console.WriteLine("Thanks For Visit !!!");
            }

            Console.ReadLine();
        }
    }
}
