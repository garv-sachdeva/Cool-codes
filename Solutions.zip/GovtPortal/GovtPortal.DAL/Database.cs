﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace GovtPortal.DAL
{
    class Database
    {
        /// <summary>
        /// Gets the govt portal strings.
        /// </summary>
        /// <value>The govt portal strings.</value>
        public static string GovtPortalStrings
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["GovtPortalStrings"].ConnectionString;
            }
        }
    }
}
