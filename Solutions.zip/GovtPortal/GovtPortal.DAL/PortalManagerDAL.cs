﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using GovtPortal.Model;

namespace GovtPortal.DAL
{
    public class PortalManagerDAL
    {
        /// <summary>
        /// Adds the user.
        /// </summary>
        /// <param name="user">The user.</param>
        /// <returns>System.Int32.</returns>
        public static int AddUser(Model.UserInfo user)
        {
            using (SqlConnection cn = new SqlConnection(Database.GovtPortalStrings))
            {
                cn.Open();

                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "AddUser";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@Name", user.Name);
                    cm.Parameters.AddWithValue("@City", user.City);
                    cm.Parameters.AddWithValue("@Phone", user.Phone);
                    cm.Parameters.AddWithValue("@DepartmentName", user.DepartmentName);
                    cm.Parameters.AddWithValue("@Ideas", user.Ideas);
                    cm.Parameters.AddWithValue("@UserId", user.UserId);
                    cm.Parameters["@UserId"].Direction = ParameterDirection.Output;
                    cm.ExecuteNonQuery();
                    user.UserId = Convert.ToInt32(cm.Parameters["@UserId"].Value);
                }
            }
            return user.UserId;
        }

        /// <summary>
        /// Gets all user.
        /// </summary>
        /// <returns>List&lt;Model.UserInfo&gt;.</returns>
        public static List<Model.UserInfo> GetAllUser()
        {
            List<UserInfo> listOfUser = new List<UserInfo>();

            using (SqlConnection cn = new SqlConnection(Database.GovtPortalStrings))
            {
                cn.Open();

                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetAllUser";
                    cm.CommandType = CommandType.StoredProcedure;

                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            listOfUser.Add(ReadUser(dr));
                        }
                    }
                }
            }
            return listOfUser;
        }

        /// <summary>
        /// Reads the user.
        /// </summary>
        /// <param name="dr">The dr.</param>
        /// <returns>UserInfo.</returns>
        private static UserInfo ReadUser(SqlDataReader dr)
        {
            UserInfo user = new UserInfo();
            
            user.Name = dr["Name"] as string;
            user.Phone = dr["Phone"] as string;
            user.City = dr["City"] as string;
            user.DepartmentName = dr["DepartmentName"] as string;
            user.Ideas = dr["Ideas"] as string;
            user.UserId = (int)dr["UserId"];
            return user;
        }

        /// <summary>
        /// Gets the user details.
        /// </summary>
        /// <param name="userId">The user identifier.</param>
        /// <returns>UserInfo.</returns>
        public static UserInfo GetUserDetails(int userId)
        {
            UserInfo user = new UserInfo();
            using (SqlConnection cn = new SqlConnection(Database.GovtPortalStrings))
            {
                cn.Open();

                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetUser";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@UserId", userId);

                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            user = ReadUser(dr);
                        }
                    }
                }
            }
            user.UserId = userId;
            return user;
        }

        /// <summary>
        /// Updates the user.
        /// </summary>
        /// <param name="user">The user.</param>
        public static void UpdateUser(UserInfo user)
        {
            using (SqlConnection cn = new SqlConnection(Database.GovtPortalStrings))
            {
                cn.Open();

                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "UpdateUser";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@Name", user.Name);
                    cm.Parameters.AddWithValue("@City", user.City);
                    cm.Parameters.AddWithValue("@Phone", user.Phone);
                    cm.Parameters.AddWithValue("@DepartmentName", user.DepartmentName);
                    cm.Parameters.AddWithValue("@Ideas", user.Ideas);
                    cm.Parameters.AddWithValue("@UserId", user.UserId);
                    cm.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Deletes the user.
        /// </summary>
        /// <param name="UserId">The user identifier.</param>
        public static void DeleteUser(int UserId)
        {
            using (SqlConnection cn = new SqlConnection(Database.GovtPortalStrings))
            {
                cn.Open();

                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "DeleteUser";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@UserId", UserId);
                    cm.ExecuteNonQuery();
                }
            }
        }
    }
}
