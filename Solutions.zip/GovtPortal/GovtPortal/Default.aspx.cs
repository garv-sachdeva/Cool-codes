﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GovtPortal.Model;
using GovtPortal.BLL;

namespace GovtPortal
{
    public partial class Default : System.Web.UI.Page
    {
        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            List<UserInfo> listOfUsers = new List<UserInfo>();
            listOfUsers = PortalManagerBLL.GetAllUser();
            GridView1.DataSource = listOfUsers;
            GridView1.DataBind();
        }

        /// <summary>
        /// Handles the Click event of the Button1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Button1_Click(object sender, EventArgs e)
        {

            UserInfo user = new UserInfo();
            user.Name = txtName.Text;
            user.City = txtCity.Text;
            user.Phone = txtPhone.Text;
            user.DepartmentName = txtDeptName.Text;
            user.Ideas = txtIdeas.Text;

            user.UserId = PortalManagerBLL.AddUser(user);

            lblNotification.Visible = true;
            lblUserId.Visible = true;
            lblUserId.Text = user.UserId.ToString(); ;

        }

        /// <summary>
        /// Rows the delete.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="GridViewCommandEventArgs"/> instance containing the event data.</param>
        protected void RowDelete(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Delete")
            {
                int UserId = Convert.ToInt32(e.CommandArgument);
                PortalManagerBLL.DeleteEmployee(UserId);
                Response.Redirect("Default.aspx");
            }
        }
    }
}