﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GovtPortal.Model;
using GovtPortal.BLL;

namespace GovtPortal
{
    public partial class EditUser : System.Web.UI.Page
    {
        int userId = int.MinValue;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            userId = Convert.ToInt32(Request.QueryString["UserId"].ToString());

            if (!IsPostBack)
            {
                UserInfo user = new UserInfo();
                user = PortalManagerBLL.GetUserDetails(userId);
                txtName.Text = user.Name;
                txtCity.Text = user.City;
                txtPhone.Text = user.Phone;
                txtDeptName.Text = user.DepartmentName;
                txtIdeas.Text = user.Ideas;
                lblID.Text = (user.UserId.ToString());
            }
            else
            {
                lblNotificationEdit.Visible = true;
                lblUserIdEdit.Visible = true;
                lblUserIdEdit.Text = userId.ToString();
            }


        }

        /// <summary>
        /// Handles the Click event of the Button1 control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Button1_Click(object sender, EventArgs e)
        {
            UserInfo editUser = new UserInfo();
            editUser.UserId = Convert.ToInt32(lblID.Text);
            editUser.Name = txtName.Text;
            editUser.City = txtCity.Text;
            editUser.Phone = txtPhone.Text;
            editUser.DepartmentName = txtDeptName.Text;
            editUser.Ideas = txtIdeas.Text;

            PortalManagerBLL.UpdateUser(editUser);


        }
    }
}