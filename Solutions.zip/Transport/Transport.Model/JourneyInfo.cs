﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transport.Model
{
    public class JourneyInfo
    {
        /// <summary>
        /// Gets or sets the vehicle.
        /// </summary>
        /// <value>The vehicle.</value>
        public string vehicle { get; set; }
        /// <summary>
        /// Gets or sets from date.
        /// </summary>
        /// <value>From date.</value>
        public DateTime FromDate { get; set; }
        /// <summary>
        /// Gets or sets to date.
        /// </summary>
        /// <value>To date.</value>
        public DateTime ToDate { get; set; }
        /// <summary>
        /// Gets or sets the distance.
        /// </summary>
        /// <value>The distance.</value>
        public int Distance { get; set; }
        /// <summary>
        /// Gets or sets the is returning.
        /// </summary>
        /// <value>The is returning.</value>
        public char IsReturning { get; set; }
        /// <summary>
        /// Gets or sets the total fare.
        /// </summary>
        /// <value>The total fare.</value>
        public float TotalFare { get; set; }
    }
}
