﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Transport.Model; // Inheriting Properties from Model Class

namespace Transport
{
     class JourneyPlanner
    {


        /// <summary>
        /// Calculates the fare.
        /// </summary>
        /// <param name="journeyInfo">The journey information.</param>
        /// <returns>System.Single.</returns>
        public float CalculateFare(JourneyInfo journeyInfo)
        {
            
            string vehicle = journeyInfo.vehicle;
            float Fare = float.MinValue;
            float discount = float.MinValue;
            float FinalAmount = float.MinValue;

            if (vehicle == "Car")
            {
                Fare = journeyInfo.Distance * 15;

                if (journeyInfo.IsReturning == 'y' || journeyInfo.IsReturning == 'Y')
                {
                    discount = (Fare * 4) / 100;
                    FinalAmount = (Fare * 2) - discount;
                }
                else
                {
                    FinalAmount = Fare;
                }
            }

            if (vehicle == "Train")
            {
                Fare = journeyInfo.Distance * 8;

                if (journeyInfo.IsReturning == 'y' || journeyInfo.IsReturning == 'Y')
                {
                    discount = (Fare * 10) / 100;
                    FinalAmount = (Fare * 2) - discount;
                }
                else
                {
                    FinalAmount = Fare;
                }
            }

            if (vehicle == "Bus")
            {
                Fare = journeyInfo.Distance * 10;

                if (journeyInfo.IsReturning == 'y' || journeyInfo.IsReturning == 'Y')
                {
                    discount = (Fare * 6) / 100;
                    FinalAmount = (Fare * 2) - discount;
                }
                else
                {
                    FinalAmount = Fare;
                }
            }

            return FinalAmount;
        }

        /// <summary>
        /// Shows the fare.
        /// </summary>
        /// <param name="listOfJourney">The list of journey.</param>
        public void ShowFare(List<JourneyInfo> listOfJourney)
        {
            foreach (var fare in listOfJourney)
            {
                if (fare.vehicle == "Car")
                {
                    Console.WriteLine("If Traveling By Car, {0}", fare.TotalFare);
                }

                if (fare.vehicle == "Bus")
                {
                    Console.WriteLine("If Traveling By Bus, {0}", fare.TotalFare);
                }

                if (fare.vehicle == "Train")
                {
                    Console.WriteLine("If Traveling By Train, {0}", fare.TotalFare);
                }
            }
        }
    }
}
