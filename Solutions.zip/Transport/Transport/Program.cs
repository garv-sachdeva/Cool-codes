﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Transport.Model; // Inheriting Properties from Model Class
using System.Text.RegularExpressions;

namespace Transport
{
    class Program : JourneyPlanner
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number of Test Cases :  ");
            int testCases = Convert.ToInt32(Console.ReadLine());

            List<JourneyInfo> listOfJourney = new List<JourneyInfo>();
            JourneyPlanner objJourney;
            JourneyInfo info = new JourneyInfo();
            float fare = float.MinValue;

            for (int index = 0; index < testCases; index++)
            {
                objJourney = new JourneyPlanner();
                listOfJourney.Add(GetJourneyDetails());
                fare =  objJourney.CalculateFare(listOfJourney[index]);
                listOfJourney[index].TotalFare = fare;
            }

            JourneyPlanner objShow = new JourneyPlanner();
            objShow.ShowFare(listOfJourney);

            Console.ReadLine();
        }

        /// <summary>
        /// Gets the journey details.
        /// </summary>
        /// <returns>JourneyInfo.</returns>
        private static JourneyInfo GetJourneyDetails()
        {
            JourneyInfo jInfo = new JourneyInfo();
            string details = Console.ReadLine();

            string[] inputs = Regex.Split(details, ", ");


            jInfo.vehicle = inputs[0];
            jInfo.FromDate = Convert.ToDateTime(inputs[1]);
            jInfo.ToDate = Convert.ToDateTime(inputs[2]);
            jInfo.Distance = Convert.ToInt32(inputs[3]);
            jInfo.IsReturning = Convert.ToChar(inputs[4]);

            return jInfo;
        }
    }
}
