﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Horror_Scope___MS101_E1
{
    /// <summary>
    /// class for calculating age and checking if person is above legal drinking age.
    /// </summary>
 
    class AgeCalculator
    {
        public void drinkCheck(int a)
        {
            if (a > 21)
                   Console.WriteLine("You are above legal drinking age");
        }
        public int age(DateTime inputDate)
        {
            DateTime today = DateTime.Today;

            int age = today.Year - inputDate.Year;

            if (today.Month < inputDate.Month)
                age = age - 1;
            else
                if ((today.Month == inputDate.Month) && (today.Day < inputDate.Day))
                  age = age - 1;
            drinkCheck(age);
            return age;
        }
    }
}
