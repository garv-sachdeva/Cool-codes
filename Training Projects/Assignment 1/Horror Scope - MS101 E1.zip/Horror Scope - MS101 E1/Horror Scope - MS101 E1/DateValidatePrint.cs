﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Horror_Scope___MS101_E1
{
    /// <summary>
    /// class for process of date validation, future date check, birthday check 
    /// </summary>

    public class DateValidatePrint
    {
        public DateTime input = new DateTime();  
        Boolean flag; 
        public string readDate;

        //function to display date in appropriate format

        public void DisplayDate(DateTime inputDate)
        {
            Console.WriteLine("you have entered {0}",String.Format("{0:dddd, MMMM d, yyyy}", inputDate));
        }

        //checking if entered date lies in future

        public Boolean FutureDate(DateTime inputDate)
        {
            DateTime now= new DateTime();
            now=DateTime.Today;

            if(inputDate.Date>now.Date)
            {
                Console.WriteLine("You have entered future date");
                return false;
            }
                else
                return true;
        }

        //if its users birthday
        
        public void BirthdayCheck(DateTime inputDate)
        {
            DateTime now= new DateTime();
            now=DateTime.Today;
            if((now.Day == inputDate.Day)&&(now.Month==inputDate.Month))
                Console.WriteLine("Happy Birthday!!");
        }

        //checking if entered date lies in future

        public Boolean OldDate(DateTime inputDate)
        {
            DateTime now = new DateTime();
            now = DateTime.Today;

            if (now.Year - inputDate.Year >100)
            {
                Console.WriteLine("You are too old to run this program");
                return false;
            }
            else
                return true;
        }

        /// <summary>
        /// Validating Date & Re-processing input if invalid date
        /// </summary>
        /// <returns></returns>
       
        public Boolean DateValidate()
        {
            var formatStrings = new string[] { "dd/MM/yyyy", "dd-MM-yyyy" };
            flag = DateTime.TryParseExact(readDate, formatStrings,CultureInfo.InvariantCulture, DateTimeStyles.None, out input);
  
            if(flag)
            flag=FutureDate(input);

            if (flag)
                flag = OldDate(input);
            
            if (flag)
                {
                   DisplayDate(input);
                   BirthdayCheck(input);
                }
                else
                {
                Console.WriteLine("You have entered an invalid date.");
                }
            return flag;
        }

    }
}
