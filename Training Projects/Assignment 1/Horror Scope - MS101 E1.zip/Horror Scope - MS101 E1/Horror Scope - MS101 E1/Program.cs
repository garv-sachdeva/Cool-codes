﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Horror_Scope___MS101_E1
{

    class Program
    {
        public static Boolean  flag;
        public static DateTime input;

        /// <summary>
        /// function for initiating the date input process
        /// </summary>
       
        public static void CallForInput()
        {
            do
            {
                Console.WriteLine("Please Enter your valid date of birth in (dd/mm/yyyy) format");
                string dateInput = Console.ReadLine();
                DateValidatePrint Obj = new DateValidatePrint();
                Obj.readDate = dateInput;
                flag = Obj.DateValidate();
                input = Obj.input;
            } while (flag==false);
        }

        /// <summary>
        /// function for loading menu option for user.
        /// </summary>
        /// <param name="next"></param>
        public static void Menu()
        {
            Console.WriteLine("Is it correct? Y/N");
            string next = Console.ReadLine();
            try
            {
                if (next[0] == 'Y' || next[0] == 'y')
                {

                    // directing to age calculator class

                    AgeCalculator obj2 = new AgeCalculator();
                    int age = obj2.age(input);
                    Console.WriteLine("Your age is{0}", age);

                    // directing to sunsign class

                    Sunsign zodiac = new Sunsign();
                    zodiac.ShowSunsign(input);
                }
                else
                {
                    CallForInput();

                    Menu();
                }
            }
            catch
            {
                Console.WriteLine("Thank you");
            }
        }


        static void Main(string[] args)
        {

           CallForInput();
 
           Menu();

           Console.ReadLine();

        }
    }
}
