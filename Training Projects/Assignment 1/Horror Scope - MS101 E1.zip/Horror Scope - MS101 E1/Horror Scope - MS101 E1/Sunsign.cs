﻿using System;


public class Sunsign
{
 
    /// <summary>
    /// declaring function to print sunsign as per the month and date of User DOB
    /// </summary>
    /// <param name="dateInput"></param>
    
    public void ShowSunsign(DateTime dateInput)
    {

        switch (dateInput.Month)
        {

            case 1:
                {
                    if (dateInput.Day <= 20)
                        Console.WriteLine("You are Capricon");

                    if (dateInput.Day >= 21)
                        Console.WriteLine("You are Aquarius");
                    break;
                }
            case 2:
                {
                    if (dateInput.Day <= 19)
                        Console.WriteLine("You are Aquarius");

                    if (dateInput.Day >= 20)
                        Console.WriteLine("You are Pisces");
                    break;
                }
            case 3:
                {
                    if (dateInput.Day <= 20)
                        Console.WriteLine("You are Pisces");

                    if (dateInput.Day >= 21)
                        Console.WriteLine("You are Aries");
                    break;
                }
            case 4:
                {
                    if (dateInput.Day <= 20)
                        Console.WriteLine("You are Aries");

                    if (dateInput.Day >= 21)
                        Console.WriteLine("You are Taurus");
                    break;
                }
            case 5:
                {
                    if (dateInput.Day <= 21)
                        Console.WriteLine("You are Taurus");

                    if (dateInput.Day >= 22)
                        Console.WriteLine("You are Gemini");
                    break;
                }
            case 6:
                {
                    if (dateInput.Day <= 21)
                        Console.WriteLine("You are Gemini");

                    if (dateInput.Day >= 22)
                        Console.WriteLine("You are Cancer");
                    break;
                }
            case 7:
                {
                    if (dateInput.Day <= 22)
                        Console.WriteLine("You are Cancer");

                    if (dateInput.Day >= 23)
                        Console.WriteLine("You are Leo");
                    break;
                }
            case 8:
                {
                    if (dateInput.Day <= 22)
                        Console.WriteLine("You are Leo");

                    if (dateInput.Day >= 23)
                        Console.WriteLine("You are Virgo");
                    break;
                }
            case 9:
                {
                    if (dateInput.Day <= 23)
                        Console.WriteLine("You are Virgo");

                    if (dateInput.Day >= 24)
                        Console.WriteLine("You are Libra");
                    break;
                }
            case 10:
                {
                    if (dateInput.Day <= 22)
                        Console.WriteLine("You are Libra");

                    if (dateInput.Day >= 23)
                        Console.WriteLine("You are Scorpio");
                    break;
                }
            case 11:
                {
                    if (dateInput.Day <= 22)
                        Console.WriteLine("You are Scorpio");

                    if (dateInput.Day >= 23)
                        Console.WriteLine("You are Sagittarius");
                    break;
                }
            case 12:
                {
                    if (dateInput.Day <= 21)
                        Console.WriteLine("You are Sagittarius");

                    if (dateInput.Day >= 22)
                        Console.WriteLine("You are Capricon");
                    break;
                }

        }
	}
}
