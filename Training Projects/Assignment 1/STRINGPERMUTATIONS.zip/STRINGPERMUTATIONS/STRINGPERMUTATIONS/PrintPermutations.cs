﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringPermutations
{
    /// <summary>
    /// class for evaluating word and printing different permutations formation
    /// </summary>
    class PrintPermutations
    {
        StringBuilder word;
        List<string> toPrint = new List<string>();

        /// <summary>
        /// swapping function
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>

        public void swap(ref StringBuilder list, int from, int i)
        {
            var temp = list[from];
            list[from] = list[i];
            list[i] = temp;
        }

        /// <summary>
        /// function to print the permutations
        /// </summary>
        /// <param name="wordPrint"></param>
        /// <param name="from"></param>
        /// <param name="length"></param>
        public void Print(StringBuilder wordPrint, int from, int length)
        {
            
                int i;

                if (from == length)
                {

                    if (!toPrint.Contains(wordPrint.ToString()))
                    {
                        toPrint.Add(wordPrint.ToString());
                        Console.Write(wordPrint);
                        Console.WriteLine(" ");

                    }
                }
                else
                    for (i = from; i <= length; i++)
                    {
                        swap(ref wordPrint, from, i);
                        Print(wordPrint, from + 1, length);
                        swap(ref wordPrint, from, i);
                    }
     
        }

        /// <summary>
        /// function accepting call from main program class
        /// </summary>
        /// <param name="word"></param>
        public void PrintPermutation(StringBuilder word)
        {
            
            int length = word.Length - 1;
            Console.WriteLine("Permutations are:");
            Print(word,0,length);  
        }

       }

    }
