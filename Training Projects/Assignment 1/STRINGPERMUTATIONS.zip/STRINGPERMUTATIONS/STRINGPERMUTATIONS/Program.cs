﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringPermutations
{
    /// <summary>
    /// main class for initiating input of word to be permutted and further passing to PrintPermutations class
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the word whose permutations are required");
            StringBuilder inputWord = new StringBuilder(Console.ReadLine());
            PrintPermutations Obj = new PrintPermutations();
            Obj.PrintPermutation(inputWord);
            Console.ReadKey();
        }
    }
}
