﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerOfHanoi
{
    /// <summary>
    /// main class which inputs the number of discs and call TowerOfHanoi Class to further evaluate
    /// </summary>

    class Program
    {
        static void Main(string[] args)
        {

            TowerOfHanoi Tobj = new TowerOfHanoi();
            string numOfDiscs;
            Console.Write("Enter number of discs: ");
            numOfDiscs = Console.ReadLine();
            Tobj.numDiscs = Convert.ToInt32(numOfDiscs);
            Tobj.MoveDisc(Tobj.numDiscs, 1, 3, 2);
            Console.ReadLine();
        }
    }
}
