﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerOfHanoi
{
    /// <summary>
    /// class for solving tower of hanoi problem
    /// </summary>
    class TowerOfHanoi
    {

        public int numDiscs;
        public TowerOfHanoi()
        {
        }
        public TowerOfHanoi(int value)
        {
            if(value!=0)
            numDiscs = value;
            else
                numDiscs = 0;
        }
        
      /// <summary>
      /// function to process movement of discs between towers
      /// </summary>
      /// <param name="n"></param>
      /// <param name="from"></param>
      /// <param name="to"></param>
      /// <param name="other"></param>
        public void MoveDisc(int n, int from, int to, int other)
        {
            if (n > 0)
            {
                MoveDisc(n - 1, from, other, to);
                Console.WriteLine("Move disk {0} from tower {1} to tower {2}", n, from, to);
                MoveDisc(n - 1, other, to, from);
            }
        }
    }
}
