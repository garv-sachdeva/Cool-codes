﻿using KeyStrokeLoggingServiceLib;
using System;
using System.ServiceModel;

namespace KeyStrokeLoggingServiceHost
{
    /// <summary>
    /// KeyStroke Logger Host Class.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Set title of console screen.
            Console.Title = KeyStrokeHostResource.consoleTitle;
            Console.WriteLine(KeyStrokeHostResource.consoleHeading);
            // Create instance of KeyStroke Logging service.
            using (ServiceHost serviceHost = new ServiceHost(typeof(KeyStrokeLoggingService)))
            {
                // Open the host and start listening for incoming messages.
                serviceHost.Open();
                // Display some infromation of service.
                DisplayHostInfo(serviceHost);
                // Keep the service running until the Enter key is pressed.
                Console.WriteLine(KeyStrokeHostResource.serviceReadyMessage);
                Console.WriteLine(KeyStrokeHostResource.terminateServiceMessage);
                Console.ReadLine();
            }
        }

        /// <summary>
        /// Method to display settings of this application.
        /// </summary>
        /// <param name="host">
        /// Parameter containing instance of host.
        /// </param>
        static void DisplayHostInfo(ServiceHost host)
        {
            Console.WriteLine();
            Console.WriteLine(KeyStrokeHostResource.hostMessage);
            foreach (System.ServiceModel.Description.ServiceEndpoint endPoint in host.Description.Endpoints)
            {
                Console.WriteLine(String.Format(KeyStrokeHostResource.hostAddress, endPoint.Address));
                Console.WriteLine(String.Format(KeyStrokeHostResource.hostBindName, endPoint.Binding.Name));
                Console.WriteLine(String.Format(KeyStrokeHostResource.hostContract, endPoint.Contract.Name));
                Console.WriteLine();
            }
            Console.WriteLine(KeyStrokeHostResource.decoration);
        }
    }
}
