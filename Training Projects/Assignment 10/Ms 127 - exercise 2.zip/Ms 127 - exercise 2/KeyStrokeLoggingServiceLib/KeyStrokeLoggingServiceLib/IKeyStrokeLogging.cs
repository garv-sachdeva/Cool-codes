﻿using System.ServiceModel;
using System.Windows.Forms;

namespace KeyStrokeLoggingServiceLib
{
    /// <summary>
    /// Interface that would serve as communication medium between external application & this application.
    /// External application can access only this interface when it needs to communicate with this application.
    /// </summary>
    [ServiceContract(Namespace = "http://garv127.com")]
    interface IKeyStrokeLogging
    {
        /// <summary>
        /// Method through external application would communicate with it.
        /// </summary>
        /// <param name="keyPressed">
        /// Parameter required from external application for further processing.
        /// </param>
        /// <returns>
        /// Message indicating success or failure in processing the parameter received by external application.
        /// </returns>
        [OperationContract]
        string LogKeyStrokeInFile(Keys keyPressed);
    }
}
