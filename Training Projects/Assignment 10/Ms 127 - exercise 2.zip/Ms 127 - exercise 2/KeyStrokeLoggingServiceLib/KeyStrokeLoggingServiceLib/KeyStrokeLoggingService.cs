﻿using System;
using System.IO;
using System.Windows.Forms;

namespace KeyStrokeLoggingServiceLib
{
    public class KeyStrokeLoggingService : IKeyStrokeLogging
    {
        #region Constructor

        /// <summary>
        /// Executes on every execution of service & displays a message.
        /// </summary>
        public KeyStrokeLoggingService()
        {
            Console.WriteLine(KeyStrokeLoggingServiceLibResource.message);
        }

        #endregion


        #region Method

        /// <summary>
        /// Interface method implementation.
        /// Method to store the keystroke in specified file.
        /// </summary>
        /// <param name="keyPressed">
        /// Parameter containing the keystroke.
        /// </param>
        /// <returns>
        /// Message indicating whether log operation was successful or not.
        /// </returns>
        public string LogKeyStrokeInFile(Keys keyPressed)
        {
            string showMessage = KeyStrokeLoggingServiceLibResource.logSuccess;
            StreamWriter keyStrokeLog;
            try
            {
                // Verify whether file already exists or not.
                if (!File.Exists(KeyStrokeLoggingServiceLibResource.filePath))
                {
                    // Create file & open it.
                    keyStrokeLog = new StreamWriter(KeyStrokeLoggingServiceLibResource.filePath);
                }
                else
                {
                    // Open file & append to it.
                    keyStrokeLog = File.AppendText(KeyStrokeLoggingServiceLibResource.filePath);
                }

                // Write to the file:
                keyStrokeLog.WriteLine(keyPressed);

                // Close the stream:
                keyStrokeLog.Close();
            }
            catch (IOException e)
            {
                showMessage = KeyStrokeLoggingServiceLibResource.logFailure;
            }
            return showMessage;
        }

        #endregion
    }
}
