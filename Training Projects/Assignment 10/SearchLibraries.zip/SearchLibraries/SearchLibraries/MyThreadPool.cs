﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SearchLibraries
{
    public class MyThreadPool
    {
        public List<Thread> threadList;
        public Queue<List<string>> queue;

        public MyThreadPool()
        {
            threadList = new List<Thread>();
            queue = new Queue<List<string>>();
        }

        public void StartThread(List<Type> classTypes)
        {
            int count = 0;

            foreach (var temp in classTypes)
            {
                count++;
                Thread thread = new Thread(() => doWork(temp, count));
                //thread.Abort();
                thread.IsBackground = true;
                thread.Name = "MyThread" + count;
                threadList.Add(thread);
                thread.Start();
            }
        }

        private void doWork(Type data, int count)
        {
            string Mythread = "MyThread" + count;
            Thread thread = null;

            foreach (var tempThread in threadList.ToList())
            {
                if (tempThread.Name == Mythread)
                {
                    thread = tempThread;
                }
            }

            List<string> list = new List<string>();

            list.Add(data.ToString());


            foreach (MethodInfo method in data.GetMethods())
            {
                list.Add("Methods:  " + method.ToString());
            }


            foreach (PropertyInfo property in data.GetProperties())
            {
                list.Add("Properties:   " + property.ToString());
            }

            foreach (ConstructorInfo constructor in data.GetConstructors())
            {
                list.Add("Constructors:   " + constructor.ToString());
            }

            //queue.Enqueue(list);

            if (thread != null)
            {
                if (thread.ThreadState != ThreadState.Running)
                {
                    queue.Enqueue(list);
                }
            }

        }
    }
}
