﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SearchLibraries
{
    class Program
    {
        static bool exceptionFlag = false;
        static Thread quitThread;

        private static void QuitApplication(Thread thread)
        {
            while (true)
            {
                ConsoleKeyInfo keyPressed = Console.ReadKey();
                if (keyPressed.Key == ConsoleKey.Escape)
                {
                    thread.Abort();
                    exceptionFlag = true;
                }
            }
        }

        public static void Main()
        {
            try
            {
                string className = "C:\\Program Files (x86)\\Reference Assemblies\\Microsoft\\Framework\\.NETFramework\\v4.5";
                var files = Directory.GetFiles(className, "*.dll");

                var assembly = Assembly.LoadFrom(files[77]);

                List<Type> classTypes = assembly.GetTypes().Where(t => t.IsClass).ToList();

                MyThreadPool myThreadPool = new MyThreadPool();

                Thread reflectionThread = new Thread(() => myThreadPool.StartThread(classTypes));

                reflectionThread.Start();


                quitThread = new Thread(() => QuitApplication(reflectionThread));
                quitThread.Start();

                while (reflectionThread.ThreadState == ThreadState.Running)
                {

                    if (myThreadPool.queue.Count != 0)
                    {
                        foreach (var temp in myThreadPool.queue.ToList())
                        {
                            foreach (var temp1 in temp)
                            {
                                Console.WriteLine(temp1);
                            }

                            Console.WriteLine();
                            Console.WriteLine();
                        }
                    }
                }
            }

            catch (Exception e)
            {
                exceptionFlag = true;
                Console.WriteLine(e.Message);
                Console.ReadLine();
            }

            finally
            {

                if (exceptionFlag == false)
                {
                    Console.WriteLine("Printing Completed");
                }
                quitThread.Abort();
                Console.ReadLine();
            }
        }   
        
    }
}
