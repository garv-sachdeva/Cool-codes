﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryManagement_v1
{
    class Display
    {
        public void DisplayTags()
        {
            Console.WriteLine(Constants.tableTag);
        }

        public void DisplayEmployee(int idOutput, string nameOutput, int annualSalaryOutput)
        {
            Console.WriteLine();
            Console.WriteLine(Constants.tableRow, idOutput, nameOutput, annualSalaryOutput);
            
        }

    }
}
