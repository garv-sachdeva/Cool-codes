﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryManagement_v1
{
    /// <summary>
    /// Employee class for creating mew employees, contains salary as per leaves function
    /// </summary>
    public class Employee
    {
        private int id;
        private string name;
        private int salary;
        private int annualPay = 0;

        int leaves = 0;

        public Employee(int id, string name, int salary)
        {
            // TODO: Complete member initialization
            this.id = id +1;
            this.name = name;
            this.salary = salary;
            this.annualPay = salary * 12;
        }
     
        public void DisplayUser()
        {
            Display employee = new Display();
            employee.DisplayEmployee(id, name, annualPay);
        }
        
        /// <summary>
        /// Comparing id for user selected employee selection
        /// </summary>
        /// <param name="i"></param>
        /// <returns></returns>
        public Boolean IdCheck(int i)
        {
            if (this.id == i)
                return true;
            else
                return false;
        }

        /// <summary>
        /// this is the calculate salary as per leaves in the month function
        /// </summary>
        /// <param name="idInput"></param>
        /// <param name="monthInput"></param>
        /// <param name="leaves"></param>
        public void LeavesCountSalary(int idInput, string monthInput, int leaves)
        {
            
            DateTime month = new DateTime();
            var formatStrings = new string[] { "MMM" };
            DateTime.TryParseExact(monthInput, formatStrings, CultureInfo.InvariantCulture, DateTimeStyles.None, out month);
            
            this.leaves = leaves;
            salary -= ((salary / DateTime.DaysInMonth(DateTime.Now.Year, month.Month)) * this.leaves);
            monthInput = String.Format("{0:MMMM}", month);
            Console.WriteLine(Constants.monthSalaryPrint, this.name, month.Month,monthInput, this.salary);
        }

        /// <summary>
        /// Validating month's input by user
        /// </summary>
        /// <param name="monthInput"></param>
        /// <returns></returns>
        internal bool ValidMonth(string monthInput)
        {
            DateTime month = new DateTime();
            var formatStrings = new string[] { "MMM" };
            Boolean flag=DateTime.TryParseExact(monthInput, formatStrings, CultureInfo.InvariantCulture, DateTimeStyles.None, out month);
            if(!flag)
                Console.WriteLine(Constants.invalid,"Month");
            return flag;
            throw new NotImplementedException();
        }
    }
}
