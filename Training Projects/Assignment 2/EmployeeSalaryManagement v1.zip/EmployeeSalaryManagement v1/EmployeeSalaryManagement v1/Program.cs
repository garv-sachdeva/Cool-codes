﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryManagement_v1
{
    class Program
    {
        static void Main(string[] args)
        {
            
            //initializing static database values

            int id = 0;
            string[] names = { "Bill", "Steve", "Michael", "Cindy", "Linda" };
            int[] salary = { 100000, 50000, 150000, 200000, 50000 };
            int leaves = 0;
            
            //creating employee class list and objects

            List<Employee> empList = new List<Employee>();
            Employee empObject = new Employee(1, "a", 1);;
            while (id < 5)
            {
                empObject = new Employee(id, names[id], salary[id]);
                empList.Add(empObject);
                id++;
            }  

            //Displaying the DB for user knowledge

            Display employee = new Display();
            employee.DisplayTags();

            
            foreach (Employee empObj in empList)
            {
                empObj.DisplayUser();
            }

            //Menu option for user

            Console.WriteLine(Constants.club,Constants.nl,Constants.menuHeader);

            //Month Input by user & further validation

            Console.WriteLine(Constants.monthInput,Constants.input,Constants.month);
            
            Boolean flag;
            string month;
            do{
                
                month = Console.ReadLine();
                flag = empObject.ValidMonth(month);

            }while (!flag);

            //ID Input by user & further Validation

            Console.WriteLine(Constants.club,Constants.input,Constants.id);
            do
            {
                id = Convert.ToInt32(Console.ReadLine());

                if (id < 6 && id > 0)
                    flag = false;
                else
                {
                    Console.WriteLine(Constants.invalid,Constants.id);
                    flag = true;
                }
            } while (flag);

            //Leaves Input by user & further validation

            Console.WriteLine(Constants.club,Constants.input,Constants.leaves);
            
            do{

                leaves = Convert.ToInt32(Console.ReadLine());
                if (leaves > 22 || leaves < 0)
                {
                    Console.WriteLine(Constants.invalid,Constants.leaves);
                    flag = true;

                }
                else
                    flag = false;
            }while(flag);

            //Printing the final query result

            Employee empPrint = new Employee(1, "a", 1);
            foreach (Employee empObj in empList)
            {
                flag = empObj.IdCheck(id);
                if(flag)
                empPrint = empObj;
            }

            empPrint.LeavesCountSalary(id, month, leaves);

            Console.ReadLine();
        }
    }
}
