﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryManagementv2
{
    class Display
    {
        
        /// <summary>
        /// individual table row display.
        /// </summary>
        /// <param name="idOutput"></param>
        /// <param name="nameOutput"></param>
        /// <param name="annualSalaryOutput"></param>
        /// <param name="typeOutput"></param>
        public void DisplayEmployee(int idOutput, string nameOutput, int annualSalaryOutput, string typeOutput)
        {
            Console.WriteLine();
            Console.WriteLine(Constants.tableRow, idOutput, nameOutput, annualSalaryOutput, typeOutput);

        }

        /// <summary>
        /// Displaying final result query solution.
        /// </summary>
        /// <param name="salEmp"></param>
        /// <param name="conEmp"></param>
        /// <param name="id"></param>
        /// <param name="month"></param>
        /// <param name="leavesOrWorkingHours"></param>
        public static void FinalResult(List<SalariedEmployee> salEmp, List<Consultant> conEmp, int id, string month, int leavesOrWorkingHours)
        {
            Boolean flag;
            foreach (SalariedEmployee empObj in salEmp)
            {
                flag = empObj.IdCheck(id);
                if (flag)
                    empObj.CountSalary(month, leavesOrWorkingHours);
            }
            foreach (Consultant empObj in conEmp)
            {
                flag = empObj.IdCheck(id);
                if (flag)
                    empObj.CountSalary(month, leavesOrWorkingHours);
            }
        }

        /// <summary>
        /// Displaying table for user information.
        /// </summary>
        /// <param name="salEmp"></param>
        /// <param name="conEmp"></param>
        /// <param name="count"></param>
        public static void DisplayDB(List<SalariedEmployee> salEmp, List<Consultant> conEmp, int count)
        {

            Console.WriteLine(Constants.nl + Constants.tableTag);

            for (int i = 0; i < count; i++)
            {

                foreach (SalariedEmployee empObj in salEmp)
                {
                    if (empObj.IdCheck(i + 1))
                        empObj.DisplayUser();
                }
                foreach (Consultant empObj in conEmp)
                {
                    if (empObj.IdCheck(i + 1))
                        empObj.DisplayUser();
                }
            }

        }

        /// <summary>
        /// Asking user for id, month and number of leaves or working hours as per user choice.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="type"></param>
        /// <param name="month"></param>
        /// <param name="leavesOrWorkingHours"></param>
        /// <returns></returns>
        public static int menuPrint(ref int id, List<int> type, ref string month, ref int leavesOrWorkingHours)
        {
            Console.WriteLine(Constants.nl + Constants.menuHeader);
            int i = 0;
           
            //ID Input by user & further Validation
            Boolean flag;

            do
            {
                Console.WriteLine(Constants.club, Constants.input, Constants.id);
                if (int.TryParse(Console.ReadLine(), out i))
                    if (i <= id && i > 0)
                        flag = false;
                    else
                    {
                        Console.WriteLine(Constants.invalid, Constants.id);
                        flag = true;
                    }
                else
                {
                    Console.WriteLine(Constants.invalid, Constants.id);
                    flag = true;
                }
            } while (flag);

            //Month Input by user & further validation
            if (type[i - 1].Equals(1))
            {

                Console.WriteLine(Constants.monthInput, Constants.input, Constants.month);
                do
                {

                    month = Console.ReadLine();
                    flag = Employee.ValidMonth(month);

                } while (!flag);
            }
            
            
            //Leaves or Working hours Input by user & further validation
            do
            {
                if (type[i - 1].Equals(1))
                {
                    Console.WriteLine(Constants.club, Constants.input, Constants.leaves);
                    if (int.TryParse(Console.ReadLine(), out leavesOrWorkingHours))
                        if (leavesOrWorkingHours > 22 || leavesOrWorkingHours < 0)
                        {
                            Console.WriteLine(Constants.invalid, Constants.leaves);
                            flag = true;    
                        }
                        else
                            flag = false;
                    else
                        flag = false;

                }
                else
                    if (type[i - 1].Equals(2))
                    {
                        Console.WriteLine(Constants.club, Constants.input, Constants.workingDays);
                        //leavesOrWorkingHours = Convert.ToInt32(Console.ReadLine());
                        if (int.TryParse(Console.ReadLine(), out leavesOrWorkingHours))
                        if (leavesOrWorkingHours > 45 || leavesOrWorkingHours < 0)
                        {
                            Console.WriteLine(Constants.invalid, Constants.workingDays);
                            flag = true;

                        }
                        else
                            flag = false;
                    }


            } while (flag);
            return i;
        }
    }
}
