﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeSalaryManagementv2
{
    class Program
    {
        /// <summary>
        /// initial fill up of databbase and creation of salaried and consultant class objects.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="salEmp"></param>
        /// <param name="conEmp"></param>
        /// <param name="names"></param>
        /// <param name="salary"></param>
        /// <param name="type"></param>
        public static void inputDB(ref int id, ref List<SalariedEmployee> salEmp, ref List<Consultant> conEmp, List<string> names, List<int> salary, List<int> type)
        {

            foreach (int typeObj in type)
            {
                if (typeObj == 1)
                {
                    SalariedEmployee salEmpObj = new SalariedEmployee(id, names[id], salary[id]);
                    salEmp.Add(salEmpObj);
                    id++;
                }
                if (typeObj == 2)
                {
                    Consultant conEmpObj = new Consultant(id, names[id], salary[id]);
                    conEmp.Add(conEmpObj);
                    id++;
                }

            }
        }
        private static void InitializeDummyData(ref List<string> names, ref List<int> salary, ref List<int> type, ref int counter, ref int leavesOrWorkingHours, ref string month, ref List<SalariedEmployee> salEmp, ref List<Consultant> conEmp)
        {
            // asking user to add new users

            Employee.addNewUser(ref names, ref salary, ref type);

            //initializing static database values & creating employee class list and objects

            inputDB(ref counter, ref salEmp, ref conEmp, names, salary, type);

            //Displaying the DB for user knowledge

            Display.DisplayDB(salEmp, conEmp, counter);
            
        }

        static void Main(string[] args)
        {
             int counter = 0;
             
             int leavesOrWorkingHours = 0;

             string month = "";

             // Lists for Salaried Employee, Consultants. Also for static DB values.

             List<SalariedEmployee> salEmp = new List<SalariedEmployee>();

             List<Consultant> conEmp = new List<Consultant>();

             List<string> names = new List<string>(new string[] {"Bill", "Steve", "Michael", "Cindy", "Linda", "Cleve", "Matt"});

             List<int> salary = new List<int>(new int[] {100000, 50000, 150000, 200000, 50000, 500, 800 });

             List<int> type = new List<int>(new int[] { 1, 1, 1, 1, 1, 2, 2 });


            // Initialize dummy data

             InitializeDummyData(ref names, ref salary, ref type, ref counter, ref leavesOrWorkingHours, ref month, ref salEmp, ref conEmp);


             //Menu option for user

             counter = Display.menuPrint(ref counter, type, ref month, ref leavesOrWorkingHours);

             //Printing the final query result

             Display.FinalResult(salEmp,conEmp,counter,month,leavesOrWorkingHours);

             Console.ReadKey();
        }

       
    }
}
