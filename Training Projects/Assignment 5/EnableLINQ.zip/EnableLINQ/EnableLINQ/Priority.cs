﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnableLINQ
{
    
    class Priority<T> : IEnumerable<Node<T>>
    {

        
        private List<Node<T>> Queue;
       
        public Priority()
        {
            Queue = new List<Node<T>>();
        }
      
        public Priority(IEnumerable<T> collection)
        {
            Queue = new List<Node<T>>();
            foreach (T item in collection)
            {
                this.Enqueue(0, item);
            }
        }
       
        public int Count
        {
            get
            {
                return Queue.Count();
            }
        }
      
        public void Clear()
        {
            Queue.Clear();
        }
    
        public void display()
        {
            foreach (Node<T> element in Queue)
            {
                Console.WriteLine("Item: {0} , Priority: {1}", element.Data, element.Priority);
            }
        }
        
        public T Dequeue()
        {
            int index = 0;

            if (Queue.Count() != 0)
            {
                int HieghestPriority = Queue[0].Priority;

                foreach (Node<T> temp in Queue)
                {
                    if (HieghestPriority < temp.Priority)
                    {
                        HieghestPriority = temp.Priority;
                        index = Queue.IndexOf(temp);
                    }
                }
                T obj = Queue[index].Data;
                Queue.Remove(Queue.ElementAt(index));
                return obj;
            }
            throw new NullReferenceException();
        }
       
        public void Enqueue(int Priority, T Data)
        {
            Node<T> newnode = new Node<T>();
            newnode.Priority = Priority;
            newnode.Data = Data;
            Queue.Add(newnode);
        }
       
        public bool Contains(T node)
        {
            foreach (Node<T> searchItem in Queue)
            {
                if (node.Equals(searchItem.Data))
                {
                    return true;
                }
            } return false;
        }
       
        public T peek()
        {
            int highestPriority = Queue[0].Priority;
            int index = 0;
            foreach (Node<T> temporary in Queue)
            {
                if (highestPriority < temporary.Priority)
                {
                    highestPriority = temporary.Priority;
                    index = Queue.IndexOf(temporary);
                }
            }
            return Queue[index].Data;
        }
    
        public IEnumerator<Node<T>> GetEnumerator()
        {
            return Queue.GetEnumerator();
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
