﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnableLINQ
{
    class Program
    {
        static void Main(string[] args)
        {

            List<string> userDefinedList = new List<string>();
            Priority<string> obj = new Priority<string>(userDefinedList);
            obj.Enqueue(8, "USA");
            obj.Enqueue(9, "India");
            obj.Enqueue(6, "SouthAfrica");
            obj.Enqueue(2, "Pakistan");
            obj.Enqueue(5, "Srilanka");
            obj.Enqueue(7, "Singapore");
            obj.Enqueue(10, "Dubai");


            /// Display Elements in the Priority Queue.

            Console.WriteLine("PRIORITY QUEUE :");
            obj.display();


            // Count the number of elements in the priority queue.

            Console.WriteLine(" Total number of element into the queue are : {0}", obj.Count);




            //Peek out the hieghest priority element from the priority queue. 

            Console.WriteLine("Hieghest Priority Item is : {0}", obj.peek());


            //Enabling LINQ
            var filter = from filterNodes in obj
                         where (filterNodes.Data.Length >= 7 && filterNodes.Data.Length <= 20)
                         select filterNodes;


            // Display the filtered list.

            Console.WriteLine("Filter Elements are:");
            foreach (var i in filter)
            {
                Console.WriteLine(i.Data);
            }

            // Checking whether priority queue is empty or not.

            try
            {
                string d = obj.Dequeue();
                Console.WriteLine("Deleted element is : {0}", d);
            }
            catch (NullReferenceException)
            {
                Console.WriteLine("Error : Queue is empty");
            }

            Console.WriteLine("Searching item in Queue:");



            //Search the item....(Item Found)
            string searchItem = "India";
            if (obj.Contains(searchItem))
            {
                Console.WriteLine("{0} :- Item Found", searchItem);
            }
            else
            {
                Console.WriteLine("{0} :-Item Not Found", searchItem);
            }

            //Search the item ...(Item not found)
            searchItem = "China";
            if (obj.Contains(searchItem))
            {
                Console.WriteLine("{0} :-Item Found", searchItem);
            }
            else
            {
                Console.WriteLine("{0} :-Item Not Found", searchItem);
            }

            // Display the number of items in priority queue after deletion
            Console.WriteLine("Total number of element in the queue after deletion are : {0}", obj.Count);


            //Clear or remove all the items from Queue.

            Console.WriteLine("Clear the Queue");
            obj.Clear();

            //Display the number of items in queue after the clear function called.

            Console.WriteLine("Total number of element in the queue are : {0}", obj.Count);

            Console.Read();

        }
    }
}
