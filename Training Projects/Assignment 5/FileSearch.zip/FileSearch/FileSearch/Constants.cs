﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSearch
{
    class Constants
    {
        public const string FileSearchSystem = "**####******* FILE SEARCH SYSTEM *******####**";
        public const string NumberOfTextFilesMessage = "NUMBER OF TEXT FILES:";
        public const string NumberOfTextFiles = "No. of txt files in {0} are: {1} \n";
        public const string FileExtensionAndSizeMessage = "FILES EXTENSIONS AND SIZE:";
        public const string FileExtensionAndSize = "Total no. of files  per extension {1} are :{0}";
        public const string Space = "\n";
        public const string LargestFiles = "TOP LARGEST FILES ARE:";
        public const string FilesAndSize = "File Name : {0}   Size: {1}Kb";
    }
}
