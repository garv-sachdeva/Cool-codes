﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Constants.FileSearchSystem);
            SearchFunctions obj = new SearchFunctions();
            obj.NumberOfTextFiles();
            obj.TotalNumberOfFiles();
            obj.TopFiveFiles();
            Console.Read();
        }
    }
}
