﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileSearch
{
    public class SearchFunctions
    {

        /// <summary>
        /// Setting path as per individual user's machine unique desktop path.
        /// </summary>
        private static string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop); 
        DirectoryInfo directoryObject = new DirectoryInfo(path);

        /// <summary>
        /// This function calculates no. of txt files in the specified directory.
        /// </summary>
        public void NumberOfTextFiles()
        {

            IEnumerable<FileInfo> file = directoryObject.GetFiles("*.txt", SearchOption.AllDirectories);
            var files = file.Count();
           // (from f in file select f).Count();
            Console.WriteLine(Constants.NumberOfTextFilesMessage);
            Console.WriteLine(Constants.NumberOfTextFiles, path, files);

        }

        /// <summary>
        /// This function calculates all extension files and there size.
        /// </summary>
        public void TotalNumberOfFiles()
        {

            var obj = from f in directoryObject.GetFiles("*", SearchOption.AllDirectories)
                      group f by f.Extension
                      ;
            Console.WriteLine(Constants.FileExtensionAndSizeMessage);
            foreach (var fl in obj)
            {
                Console.WriteLine(Constants.FileExtensionAndSize, fl.Count(), fl.Key);
            }
            Console.WriteLine(Constants.Space);
        }

        /// <summary>
        /// This function calculates TopFive files according to their sizes in decending order.
        /// </summary>
        public void TopFiveFiles()
        {

            var obj1 = (from a in directoryObject.GetFiles("*", SearchOption.AllDirectories)
                        orderby a.Length descending
                        select a).Take(5);
            Console.WriteLine(Constants.LargestFiles);
            foreach (var fl in obj1)
            {
                Console.WriteLine(Constants.FilesAndSize, fl.Name, fl.Length / 1024);
            }

        }

    }
}
