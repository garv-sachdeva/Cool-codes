﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrioirtyQueue
{
    
    /// <summary>
    /// Node class for declaring default two data values.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Node<T>
    {
        private int priority;
        private T data;

        public int Priority
        {
            get { return priority; }
            set { priority = value; }
        }

        public T Data { 
            get { return data; }
            set{ data = value; } }
    }

}
