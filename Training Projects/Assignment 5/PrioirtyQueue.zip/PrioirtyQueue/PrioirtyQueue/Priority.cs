﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrioirtyQueue
{
    /// <summary>
    /// This class works on generic data instance, and have functions like count, clear, enqueue, dequeue, display to work on a list queue.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Priority<T>
    {
        private List<Node<T>> Queue;
        
        public int Count
        {
              get
            {
                return Queue.Count();
            }
        }

        /// <summary>
        /// Deleting all the values in queue.
        /// </summary>
        public void Clear()
        {
            Queue.Clear();
        }
        
        /// <summary>
        /// display function for printing queue.
        /// </summary>
         public void display()
        {
            foreach (Node<T> element in Queue)
            {
                Console.WriteLine("Item: {0} , Priority: {1}", element.Data, element.Priority);
            }
        }

        /// <summary>
        /// This function pops out an element from queue.
        /// </summary>
        /// <returns></returns>
        public T Dequeue()
        {
            int index = 0;

            if (Queue.Count() != 0)
            {
                int HighestPriority = Queue[0].Priority;

                foreach (Node<T> temp in Queue)
                {
                    if (HighestPriority < temp.Priority)
                    {
                        HighestPriority = temp.Priority;
                        index = Queue.IndexOf(temp);
                    }
                }
                T obj = Queue[index].Data;
                Queue.Remove(Queue.ElementAt(index));
                return obj;
            }
            throw new NullReferenceException();
        }

        /// <summary>
        /// this function searches for a particular data value in queue.
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        public bool Contains(T node)
        {
            foreach (Node<T> searchItem in Queue)
            {
                if (node.Equals(searchItem.Data))
                {
                    return true;
                }
            } return false;
        }

        /// <summary>
        /// Default constructor for class objects.
        /// </summary>
        public Priority()
        {
            Queue = new List<Node<T>>();
        }

        /// <summary>
        /// This function creates a new list(filtered) on basis of some logic using predicate boolean as a condition.
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
         public IEnumerable<Node<T>> Filter(Func<Node<T>, bool> predicate)
        {
            List<Node<T>> filteredList = new List<Node<T>>();
            foreach (Node<T> node in Queue)
            {
                if (predicate(node))
                {
                    filteredList.Add(node);
                }
            }
            return filteredList;
        }

        /// <summary>
        /// Constructor with paratmer for imputting default values.
        /// </summary>
        /// <param name="collection"></param>
        public Priority(IEnumerable<T> collection)
        
        {
            Queue = new List<Node<T>>();
            foreach(T item in collection)
            this.Enqueue(0, item);
        }

        /// <summary>
        /// Enqueue function for pushing values into queue.
        /// </summary>
        /// <param name="priority"></param>
        /// <param name="data"></param>
        public void Enqueue(int priority,T data)
        {
 	            Node<T> newnode = new Node<T>();
                newnode.Priority = priority;
                newnode.Data = data;
                Queue.Add(newnode);
        }

        /// <summary>
        /// This function looks for highest priority value inside queue.
        /// </summary>
        /// <returns></returns>
        public T Peek()
        {
            int highestPriority = Queue[0].Priority;
            int index = 0;
            foreach (Node<T> temporary in Queue)
            {
                if (highestPriority < temporary.Priority)
                {
                    highestPriority = temporary.Priority;
                    index = Queue.IndexOf(temporary);
                }
            }
            return Queue[index].Data;
        }
        
       
    }
}