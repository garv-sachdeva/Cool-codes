﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    class IssueManager
    {
        public struct Issue
        {
            public int IssueId;
            public string Title;
            public string Description;
            public DateTime DatePosted;
            public int PostedBy;
            public int AssignedTo;
            public byte Status;
            public byte Priority;
            public string Comment;
            public DateTime DateModified;
        }

        public static Issue AddIssue(Issue IssueData)
        {
            using (SqlConnection cn = new SqlConnection(DB.EmployeePortalString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "AddIssue";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@title", IssueData.Title);
                    cm.Parameters.AddWithValue("@description", IssueData.Description);
                    cm.Parameters.AddWithValue("@postedBy", IssueData.PostedBy);
                    cm.Parameters.AddWithValue("@assignedTo", IssueData.AssignedTo);
                    cm.Parameters.AddWithValue("@status", IssueData.Status);
                    cm.Parameters.AddWithValue("@priority", IssueData.Priority);

                    IssueData.IssueId = Convert.ToInt32(cm.ExecuteScalar());
                }
            }

            return IssueData;
        }

        public static List<Issue> GetAllIssues()
        {
            List<Issue> issues = new List<Issue>();

            using (SqlConnection cn = new SqlConnection(DB.EmployeePortalString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetAllIssues";
                    cm.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            issues.Add(ReadIssue(dr));
                        }
                    }
                }
            }
            return issues;
        }

        private static Issue ReadIssue(SqlDataReader dr)
        {
            Issue IssueData = new Issue();
            IssueData.IssueId = (int)dr["IssueId"];
            IssueData.Title = dr["Title"] as string;
            IssueData.Description = dr["Description"] as string;
            IssueData.DatePosted = (DateTime)dr["DatePosted"];
            IssueData.PostedBy = (int)dr["PostedBy"];
            IssueData.AssignedTo = (int)dr["AssignedTo"];
            IssueData.Status = (byte)dr["Status"];
            IssueData.Priority = (byte)dr["Priority"];

            return IssueData;
        }

        public static Issue GetIssue(int issueId)
        {
            Issue issueData = new Issue();
            issueData.IssueId = issueId;

            using (SqlConnection cn = new SqlConnection(DB.EmployeePortalString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetIssue";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@issueId", issueData.IssueId);
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            issueData = ReadIssue(dr);
                        }
                        else
                        {
                            throw new ApplicationException(string.Format("Issue({0}) not found.", issueData.IssueId));
                        }
                    }
                }
            }
            return issueData;
        }

        public static List<Issue> GetAllOpenIssues()
        {
            List<Issue> issues = new List<Issue>();

            using (SqlConnection cn = new SqlConnection(DB.EmployeePortalString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "GetAllOpenIssues";
                    cm.CommandType = CommandType.StoredProcedure;
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            issues.Add(ReadIssue(dr));
                        }
                    }
                }
            }
            return issues;
        }

        public static void updtaeIssue(Issue IssueData)
        {
            using (SqlConnection cn = new SqlConnection(DB.EmployeePortalString))
            {
                cn.Open();
                using (SqlCommand cm = cn.CreateCommand())
                {
                    cm.CommandText = "UpdateIssue";
                    cm.CommandType = CommandType.StoredProcedure;
                    cm.Parameters.AddWithValue("@issueId", IssueData.IssueId);
                    cm.Parameters.AddWithValue("@title", IssueData.Title);
                    cm.Parameters.AddWithValue("@description", IssueData.Description);
                    cm.Parameters.AddWithValue("@postedBy", IssueData.PostedBy);
                    cm.Parameters.AddWithValue("@assignedTo", IssueData.AssignedTo);
                    cm.Parameters.AddWithValue("@status", IssueData.Status);
                    cm.Parameters.AddWithValue("@priority", IssueData.Priority);
                    cm.Parameters.AddWithValue("@comment", IssueData.Comment);

                    cm.ExecuteNonQuery();
                }
            }
        }
    }
}
