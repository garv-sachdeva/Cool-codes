﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    class DepartmentList : List<Department>
    {
        private DepartmentList()
        { }

        public static DepartmentList GetAllDept()
        {
            DepartmentList deptList = new DepartmentList();
            deptList.fetchAll();
            return deptList;
        }

        public void fetchAll()
        {
            List<DepartmentManager.Department> dep = new List<DepartmentManager.Department>();

            foreach (var item in dep)
            {
                Department department = new Department();
                department.DepartmentId = item.DepartmentId;
                department.DepartmentName = item.DepartmentName;
                this.Add(department);
            }
        }
    }
}
