﻿using DataLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    class EmployeeList : List<Employee>
    {
        private EmployeeList()
        {
        }

        public static EmployeeList GetAllEmployees()
        {
            EmployeeList empList = new EmployeeList();
            empList.fetchAll();
            return empList;
        }

        public void fetchAll()
        {
            List<EmployeeManager.Employee> empList = new List<EmployeeManager.Employee>();

            foreach (var item in empList)
            {
                Employee emp = Employee.GetEmployee(item);
                this.Add(emp);

            }
        }
    }
}
