﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFormsApp
{
    public partial class GetEmployee : Form
    {
        public GetEmployee()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //string connString = DataLayer.DB.EmployeePortalString;
            SqlConnection conn = DataLayer.DB.GetSqlConn();
        }

        private void buttonGetEmp(object sender, EventArgs e)
        {
            DataLayer.EmployeeManager.Employee emp = new DataLayer.EmployeeManager.Employee();
            
            emp = DataLayer.EmployeeManager.GetEmp(int.Parse(textBoxId.Text));

            textBoxFName.Text = emp.FirstName;
            textBoxLName.Text = emp.LastName;
            textBoxEmpCode.Text = emp.EmployeeCode;
            textBoxEmail.Text = emp.Email;
            textBoxDept.Text = emp.DepartmentId.ToString();
            textBoxFName.Text = emp.FirstName;
            textBoxDOB.Text = emp.DOB.ToString();
            textBoxDoj.Text = emp.DateOfJoining.ToString();
            textBoxDeptName.Text = emp.DepartmentName.ToString();
        }

        
    }
}
